package com.example.Microservices615.controller;

import com.example.Microservices615.dto.LoginRequest;
import com.example.Microservices615.security.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final JwtUtil jwtUtil;

    public AuthController(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        String username = loginRequest.getUsername();
        String password = loginRequest.getPassword();

        // Demo User 1
        if ("user".equals(username) && "password".equals(password)) {
            String token = jwtUtil.generateToken(username, List.of("USER"));
            return ResponseEntity.ok(Map.of("token", token, "username", username, "role", "USER"));
        }

        // Demo User 2 (Admin)
        if ("admin".equals(username) && "password".equals(password)) {
            String token = jwtUtil.generateToken(username, List.of("ADMIN"));
            return ResponseEntity.ok(Map.of("token", token, "username", username, "role", "ADMIN"));
        }

        return ResponseEntity.status(401).body("Invalid username or password");
    }
}