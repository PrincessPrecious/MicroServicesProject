package com.example.Microservices615.controller;

import com.example.Microservices615.dto.TaskDTO;
import com.example.Microservices615.entity.Task;
import com.example.Microservices615.repository.TaskRepository;
import jakarta.validation.Valid;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskRepository taskRepository;

    public TaskController(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    @GetMapping
    public List<Task> getMyTasks() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return taskRepository.findByUsername(username);
    }

    
    @PostMapping
    public Task createTask(@Valid @RequestBody TaskDTO taskDTO) {
        try {
            String username = SecurityContextHolder.getContext().getAuthentication().getName();

            System.out.println("DEBUG: Creating task for user = " + username);

            if (username == null || username.isEmpty()) {
                throw new RuntimeException("User authentication failed - username is null");
            }

            Task task = new Task();
            task.setTitle(taskDTO.getTitle());
            task.setDescription(taskDTO.getDescription() != null ? taskDTO.getDescription() : "");
            task.setStatus(taskDTO.getStatus() != null ? taskDTO.getStatus() : "PENDING");
            task.setUsername(username);

            Task savedTask = taskRepository.save(task);
            System.out.println("✅ Task saved successfully! ID = " + savedTask.getId());
            
            return savedTask;

        } catch (Exception e) {
            System.err.println("❌ Error creating task: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }
    @DeleteMapping("/{id}")
    public void deleteTask(@PathVariable Long id) {
        taskRepository.deleteById(id);
    }
}