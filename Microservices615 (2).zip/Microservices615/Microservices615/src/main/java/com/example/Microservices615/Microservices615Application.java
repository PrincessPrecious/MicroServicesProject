package com.example.Microservices615;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Microservices615Application {

	public static void main(String[] args) {
		SpringApplication.run(Microservices615Application.class, args);
	}

}
