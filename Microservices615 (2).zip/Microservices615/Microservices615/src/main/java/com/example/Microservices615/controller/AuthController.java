package com.example.Microservices615.controller;

import com.example.Microservices615.dto.LoginRequest;
import com.example.Microservices615.security.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final JwtUtil jwtUtil;

    public AuthController(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        // Demo credentials (Change later with real database users)
        if ("user".equals(loginRequest.getUsername()) && "password".equals(loginRequest.getPassword())) {
            String token = jwtUtil.generateToken(loginRequest.getUsername(), List.of("USER"));
            return ResponseEntity.ok(Map.of("token", token, "username", loginRequest.getUsername()));
        }
        return ResponseEntity.status(401).body("Invalid username or password");
    }
}