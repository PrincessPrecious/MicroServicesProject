package com.example.Microservices615;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Microservices615ApplicationTests {

	@Test
	void contextLoads() {
	}

}
